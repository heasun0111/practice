import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class ButtonPanel extends JPanel{

   private static final long serialVersionUID = 1L;
   private JButton Rectangle ,Polygon, Oval, Line,Resize,Plus,Minus,Undo,Redo,Eraser,Era1,Era2,Era3,Thickness,Thickness1,Thickness2,Thickness3
   ,Col,BackCol,Pen,Jwa,Woo,Sang,Ha,Fill;
   DrawPanel drawPanel;
   private int thicknum = 1;
   private int polynum = 5;
   private Color colornum = Color.BLACK;
   private int fill = 0;
   boolean isEraVisible;
   boolean isThicknessVisible;
   int Thicknesssize;
   int Erasize;
    public ButtonPanel()
    {
        //��ġ �ڵ����� ����
        this.setLayout(null);
        this.setSize(1920,200);
        
                Pen= new JButton(new ImageIcon(getClass().getResource("Pen.png")));
                Rectangle= new JButton(new ImageIcon(getClass().getResource("Rectangle.png")));
                Polygon= new JButton(new ImageIcon(getClass().getResource("Polygon.png")));
                Oval= new JButton(new ImageIcon(getClass().getResource("Oval.png")));
                Line= new JButton(new ImageIcon(getClass().getResource("Line.png")));
                Resize= new JButton(new ImageIcon(getClass().getResource("Resize.png")));
                Plus= new JButton(new ImageIcon(getClass().getResource("Plus.png")));
                Minus= new JButton(new ImageIcon(getClass().getResource("Minus.png")));
                Undo= new JButton(new ImageIcon(getClass().getResource("Undo.png")));
                Redo= new JButton(new ImageIcon(getClass().getResource("Redo.png")));
                Eraser= new JButton(new ImageIcon(getClass().getResource("Eraser.png")));
                Era1= new JButton(new ImageIcon(getClass().getResource("Era1.png")));
                Era2= new JButton(new ImageIcon(getClass().getResource("Era2.png")));
                Era3= new JButton(new ImageIcon(getClass().getResource("Oval.png")));
                Thickness= new JButton(new ImageIcon(getClass().getResource("Thickness.png")));
                Thickness1= new JButton(new ImageIcon(getClass().getResource("Thickness1.png")));
                Thickness2= new JButton(new ImageIcon(getClass().getResource("Thickness2.png")));
                Thickness3= new JButton(new ImageIcon(getClass().getResource("Thickness3.png")));
                Col= new JButton(new ImageIcon(getClass().getResource("Col.png")));
                BackCol= new JButton(new ImageIcon(getClass().getResource("BackCol.png")));
                Jwa= new JButton(new ImageIcon(getClass().getResource("Jwa.png")));
                Woo= new JButton(new ImageIcon(getClass().getResource("Woo.png")));
                Sang= new JButton(new ImageIcon(getClass().getResource("Sang.png")));
                Ha= new JButton(new ImageIcon(getClass().getResource("Ha.png")));
                Fill= new JButton(new ImageIcon(getClass().getResource("Fill.png")));
                
                Pen.setBackground(Color.white);
                Rectangle.setBackground(Color.white);
                Polygon.setBackground(Color.white);
                Oval.setBackground(Color.white);
                Line.setBackground(Color.white);
                Resize.setBackground(Color.white);
                Plus.setBackground(Color.white);
                Minus.setBackground(Color.white);
                Undo.setBackground(Color.white);
                Redo.setBackground(Color.white);
                Eraser.setBackground(Color.white);
                Era1.setBackground(Color.white);
                Era2.setBackground(Color.white);
                Era3.setBackground(Color.white);
                Thickness.setBackground(Color.white);
                Thickness1.setBackground(Color.white);
                Thickness2.setBackground(Color.white);
                Thickness3.setBackground(Color.white);
                Col.setBackground(Color.white);
                BackCol.setBackground(Color.BLACK);
                Jwa.setBackground(Color.white);
                Woo.setBackground(Color.white);
                Sang.setBackground(Color.white);
                Ha.setBackground(Color.WHITE);
                Fill.setBackground(Color.WHITE);

                //Pen
                Pen.addActionListener(new MyActionListener());
                this.add(Pen);
                Pen.setBounds(0,0,64,64);
                //Rectangle
                Rectangle.addActionListener(new MyActionListener());
                this.add(Rectangle);
                Rectangle.setBounds(64,0,64,64);
                //Polygon
                Polygon.addActionListener(new MyActionListener());
                this.add(Polygon);
                Polygon.setBounds(128,0,64,64);
                //Oval
                Oval.addActionListener(new MyActionListener());
                this.add(Oval);
                Oval.setBounds(192,0,64,64);
                //Line
                Line.addActionListener(new MyActionListener());
                this.add(Line);
                Line.setBounds(256,0,64,64);
                //Resize
                Resize.addActionListener(new MyActionListener());
                this.add(Resize);
                Resize.setBounds(320,0,64,64);
                //Plus
                Plus.addActionListener(new MyActionListener());
                this.add(Plus);
                Plus.setBounds(384,0,64,64);
                //Minus
                Minus.addActionListener(new MyActionListener());
                this.add(Minus);
                Minus.setBounds(448,0,64,64);
                //Undo
                Undo.addActionListener(new MyActionListener());
                this.add(Undo);
                Undo.setBounds(512,0,64,64);
                //Redo
                Redo.addActionListener(new MyActionListener());
                this.add(Redo);
                Redo.setBounds(576,0,64,64);
                //Eraser
                Eraser.addActionListener(new MyActionListener());
                this.add(Eraser);
                Eraser.setBounds(640,0,64,64);
                //Era1
                Era1.addActionListener(new MyActionListener());
                this.add(Era1);
                Era1.setBounds(640,68,64,32);
                //Era2
                Era2.addActionListener(new MyActionListener());
                this.add(Era2);
                Era2.setBounds(640,99,64,32);
                //Era3
                Era3.addActionListener(new MyActionListener());
                this.add(Era3);
                Era3.setBounds(640,131,64,32);
                //Thickness
                Thickness.addActionListener(new MyActionListener());
                this.add(Thickness);
                Thickness.setBounds(704,0,64,64);
                //Thickness1
                Thickness1.addActionListener(new MyActionListener());
                this.add(Thickness1);
                Thickness1.setBounds(704,68,64,32);
                //Thickness2
                Thickness2.addActionListener(new MyActionListener());
                this.add(Thickness2);
                Thickness2.setBounds(704,99,64,32);
                //Thickness3
                Thickness3.addActionListener(new MyActionListener());
                this.add(Thickness3);
                Thickness3.setBounds(704,131,64,32);
                //Col
                Col.addActionListener(new MyActionListener());
                this.add(Col);
                Col.setBounds(768,0,64,64);
                //BackCol
                BackCol.addActionListener(new MyActionListener());
                this.add(BackCol);
                BackCol.setBounds(832,0,64,64);
                //Jwa
                Jwa.addActionListener(new MyActionListener());
                this.add(Jwa);
                Jwa.setBounds(896,0,32,64);
                //Woo
                Woo.addActionListener(new MyActionListener());
                this.add(Woo);
                Woo.setBounds(928,0,32,64);
                //Sang
                Sang.addActionListener(new MyActionListener());
                this.add(Sang);
                Sang.setBounds(960,0,64,32);
                //Ha
                Ha.addActionListener(new MyActionListener());
                this.add(Ha);
                Ha.setBounds(960,33,64,32);
                //Fill
                Fill.addActionListener(new MyActionListener());
                this.add(Fill);
                Fill.setBounds(1024,0,64,64);

                
                //�г�ũ�� �� ��ư ����+�ʱ�ȭ
                Undo.setEnabled(true);
                Redo.setEnabled(false);
                Thickness1.setVisible(false);
                Thickness2.setVisible(false);
                Thickness3.setVisible(false);
                Era1.setVisible(false);
                Era2.setVisible(false);
                Era3.setVisible(false);
                
                drawPanel = new DrawPanel(polynum,colornum,thicknum);
                drawPanel.setBounds(0,65,1920,880);
                this.add(drawPanel);
                

            }
       
       
                   

           //��ư �������� �ϴ� �ൿ
            class MyActionListener implements ActionListener{
            
                @Override
                public void actionPerformed(ActionEvent e) {
                    Object source=e.getSource();
                    
                    
                    if(source==Pen){
                    	polynum = 5;
                    	drawPanel.reset(polynum,colornum,thicknum,fill);

                        Thickness1.setVisible(false);
                        Thickness2.setVisible(false);
                        Thickness3.setVisible(false); 
                        Undo.setEnabled(true);
                     }
                    else if(source==Rectangle)
                    {
                       polynum = 2;
                       drawPanel.reset(polynum,colornum,thicknum,fill);
                       
                    }
                    else if(source==Polygon)
                    {
                       polynum = 4;
                       drawPanel.reset(polynum,colornum,thicknum,fill);
                       
                    }
                    else if(source==Oval){
                       polynum = 3;
                       drawPanel.reset(polynum,colornum,thicknum,fill);
                    }
                    else if(source==Line){
                       polynum = 1;
                       drawPanel.reset(polynum,colornum,thicknum,fill);
                      
                    }
                    else if(source==Resize){
                    	drawPanel.choose();
                    }
                    else if(source==Plus){
                    	drawPanel.sizeUp();
                    }
                    else if(source==Minus){
                    	drawPanel.sizeDown();
                        Undo.setEnabled(true);//undo Ȱ��ȭ
                    }
                    else if(source==Undo){
                       drawPanel.undo();
                       Redo.setEnabled(true);//redo Ȱ��ȭ
                    }
                    else if(source==Redo){
                       drawPanel.redo();
                       if(drawPanel.lastColor.isEmpty())
                       {
                          Redo.setEnabled(false);
                       }
                    }
                    else if(source==Eraser){//���찳 ũ�⼱��â ����
                         
                         isEraVisible = Era1.isVisible();
                         polynum = 5;
                         
                       Thickness1.setVisible(false);
                       Thickness2.setVisible(false);
                       Thickness3.setVisible(false);
                       Era1.setVisible(true);
                       Era2.setVisible(true);
                       Era3.setVisible(true);
                      

                       
                       if(isEraVisible == true) {
                            Era1.setVisible(false);
                            Era2.setVisible(false);
                            Era3.setVisible(false);   
                            
                        } 
                    }
                        
                    else if(source==Thickness){//���� ũ�⼱��â ����
                     
                       isThicknessVisible = Thickness1.isVisible();
                         
                       Thickness1.setVisible(true);
                       Thickness2.setVisible(true);
                       Thickness3.setVisible(true);
                       Era1.setVisible(false);
                       Era2.setVisible(false);
                       Era3.setVisible(false);
                       
                       if(isThicknessVisible == true) {
                            Thickness1.setVisible(false);
                            Thickness2.setVisible(false);
                            Thickness3.setVisible(false);   
                            
                        } 
                        
                    }
                    else if(source==Thickness1){
                    	thicknum = 1;
                    	drawPanel.reset(polynum,colornum,thicknum,fill);
          
                        Thickness1.setVisible(false);
                        Thickness2.setVisible(false);
                        Thickness3.setVisible(false);
                        Undo.setEnabled(true);
                    }
                    else if(source==Thickness2){
                    	thicknum = 10;
                    	drawPanel.reset(polynum,colornum,thicknum,fill);
                        Thickness1.setVisible(false);
                        Thickness2.setVisible(false);
                        Thickness3.setVisible(false);
                        Undo.setEnabled(true);
                    }
                    else if(source==Thickness3){
                    	thicknum = 20;
                    	drawPanel.reset(polynum,colornum,thicknum,fill);
                        Thickness1.setVisible(false);
                        Thickness2.setVisible(false);
                        Thickness3.setVisible(false);
                        Undo.setEnabled(true);
                    }
                    else if(source==Era1){
                        colornum = Color.WHITE;
                        thicknum = 10;
                        drawPanel.reset(polynum,colornum,thicknum,fill);
                        Era1.setVisible(false);
                        Era2.setVisible(false);
                        Era3.setVisible(false);
                        Undo.setEnabled(true);
                    }
                    else if(source==Era2){
                        colornum = Color.WHITE;
                        thicknum = 20;
                        drawPanel.reset(polynum,colornum,thicknum,fill);
                        Era1.setVisible(false);
                        Era2.setVisible(false);
                        Era3.setVisible(false);
                        Undo.setEnabled(true);
                    }
                    else if(source==Era3){
                        colornum = Color.WHITE;
                        thicknum = 30;
                        drawPanel.reset(polynum,colornum,thicknum,fill);
                        Era1.setVisible(false);
                        Era2.setVisible(false);
                        Era3.setVisible(false);
                        Undo.setEnabled(true);
                    }            

                    else if(source==Col){
                       
                       colornum = JColorChooser.showDialog(null, "������", Color.blue);
                       drawPanel.reset(polynum,colornum,thicknum,fill);
                       Thickness1.setVisible(false);
                       Thickness2.setVisible(false);
                       Thickness3.setVisible(false);
                       Era1.setVisible(false);
                       Era2.setVisible(false);
                       Era3.setVisible(false);
                    }
                    else if(source==BackCol){
                        
                        Color color = JColorChooser.showDialog(null, "������", Color.blue);
                        drawPanel.changeColor(color);
                        Thickness1.setVisible(false);
                        Thickness2.setVisible(false);
                        Thickness3.setVisible(false);
                        Era1.setVisible(false);
                        Era2.setVisible(false);
                        Era3.setVisible(false);
                     }
                    
                    else if(source==Jwa){

                    	drawPanel.left();
                        Thickness1.setVisible(false);
                        Thickness2.setVisible(false);
                        Thickness3.setVisible(false); 
                        Era1.setVisible(false);
                        Era2.setVisible(false);
                        Era3.setVisible(false);
                        Undo.setEnabled(true);
                     }
                    else if(source==Woo){

                    	drawPanel.right();
                        Thickness1.setVisible(false);
                        Thickness2.setVisible(false);
                        Thickness3.setVisible(false); 
                        Era1.setVisible(false);
                        Era2.setVisible(false);
                        Era3.setVisible(false);
                        Undo.setEnabled(true);
                     }
                    else if(source==Sang){

                    	drawPanel.up();
                        Thickness1.setVisible(false);
                        Thickness2.setVisible(false);
                        Thickness3.setVisible(false); 
                        Era1.setVisible(false);
                        Era2.setVisible(false);
                        Era3.setVisible(false);
                        Undo.setEnabled(true);
                     }
                    else if(source==Ha){

                    	drawPanel.down();
                        Thickness1.setVisible(false);
                        Thickness2.setVisible(false);
                        Thickness3.setVisible(false); 
                        Era1.setVisible(false);
                        Era2.setVisible(false);
                        Era3.setVisible(false);
                        Undo.setEnabled(true);
                     }
                    else if(source==Fill){

                    	if(fill == 0)
                    	{
                    		fill = 1;
                    	}
                    	else if(fill == 1)
                    	{
                    		fill = 0;
                    	}
                    	drawPanel.reset(polynum,colornum,thicknum,fill);
                        Thickness1.setVisible(false);
                        Thickness2.setVisible(false);
                        Thickness3.setVisible(false); 
                        Era1.setVisible(false);
                        Era2.setVisible(false);
                        Era3.setVisible(false);
                        Undo.setEnabled(true);
                     }
                    
                    else {
                       

                    }
                }
                }
            }