import java.awt.GridLayout;
import javax.swing.JFrame;


public class GUI extends JFrame
{
	private static final long serialVersionUID = 1L;

	public GUI()
	{
		super("Painter");
		
		GridLayout gridbag = new GridLayout(1,1);
		this.setLayout(gridbag);
		
		MenuPanel menuPanel = new MenuPanel();
		this.setJMenuBar(menuPanel);
		
		ButtonPanel buttonPanel = new ButtonPanel();
	    buttonPanel.setBounds(0,20,1920,880);
	    this.add(buttonPanel,0);
	    
	    menuPanel.getDrawPanel(buttonPanel.drawPanel);
		
		
		setSize(1920,1080);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setVisible(true);
		
	}
}
