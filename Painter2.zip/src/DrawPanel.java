import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Line2D;
import java.util.ArrayList;
import java.util.Stack;
import java.util.Vector;

public class DrawPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	Vector<Point> sv = new Vector<Point>(); // ����
	Vector<Point> se = new Vector<Point>(); // ����
	private int figureNum = 0;
	private static Color color;
	private static int polygon;
	private int thick;
	private int fill;
	private Image con;
	private static ArrayList<Integer> polygoncase = new ArrayList<>();
	private static ArrayList<Color> colorcase = new ArrayList<>();
	private static ArrayList<Integer> thickcase = new ArrayList<>();
	private static ArrayList<Integer> fillcase = new ArrayList<>();
	public Stack<Color> lastColor = new Stack<>();
	public Stack<Color> selectLast = new Stack<>();
	private Stack<Integer> intNum = new Stack<>();
	
	public DrawPanel(int polyNum , Color col, int thicknum)
	{
		polygon = polyNum;
		color = col;
		thick = thicknum;
		this.setBackground(Color.WHITE);
		this.setSize(1920,816);
		this.addMouseListener(new MyMouseListener()); // ������
		this.addMouseMotionListener(new MyMouseMotionListener());
		
	}
		
	public void paintComponent(Graphics g)
	{		
		super.paintComponent(g);
		
		g.drawImage(con,0,0,null);
		for(int i=0;i<sv.size();i++)
		{ //����ũ�⸸ŭ
			Point sp = sv.get(i); // ���Ͱ���������
			Point ep = se.get(i);	
			g.setColor(colorcase.get(i));
			Graphics2D g2=(Graphics2D)g;
			g2.setStroke(new BasicStroke(thickcase.get(i),BasicStroke.CAP_ROUND,0));
			if(polygoncase.get(i) == 1)
			{
				g.drawLine(sp.x, sp.y, ep.x, ep.y);//�׸���
			}
			else if(polygoncase.get(i) == 2)
			{
				int[] x = {sp.x, sp.x, ep.x, ep.x};
				int[] y = {sp.y, ep.y, ep.y, sp.y};
				if(fillcase.get(i) == 0)
				{
					g.drawPolygon(x,y,4);
				}
				else
				{
					g.fillPolygon(x, y, 4);
				}
			}
			else if(polygoncase.get(i) == 3)
			{
				if(fillcase.get(i) == 0)
				{
					if(sp.x > ep.x  && sp.y > ep.y)
					{
						g.drawOval(ep.x, ep.y, sp.x-ep.x, sp.y-ep.y);
					}
					else if(sp.y > ep.y)
					{
						g.drawOval(sp.x, ep.y, ep.x-sp.x, sp.y-ep.y);
					}
					else if(sp.x > ep.x)
					{
						g.drawOval(ep.x, sp.y, sp.x-ep.x, ep.y-sp.y);
					}
					else
					{
						g.drawOval(sp.x, sp.y, ep.x-sp.x, ep.y-sp.y);
					}
				}
				else
				{
					if(sp.x > ep.x  && sp.y > ep.y)
					{
						g.fillOval(ep.x, ep.y, sp.x-ep.x, sp.y-ep.y);
					}
					else if(sp.y > ep.y)
					{
						g.fillOval(sp.x, ep.y, ep.x-sp.x, sp.y-ep.y);
					}
					else if(sp.x > ep.x)
					{
						g.fillOval(ep.x, sp.y, sp.x-ep.x, ep.y-sp.y);
					}
					else
					{
						g.fillOval(sp.x, sp.y, ep.x-sp.x, ep.y-sp.y);
					}
				}
			}
			else if(polygoncase.get(i) == 4)
			{
				int[] x = {sp.x, ep.x, (sp.x+ep.x)/2};
				int[] y = {ep.y, ep.y, sp.y};
				if(fillcase.get(i) == 0)
				{
					g.drawPolygon(x,y,3);
				}
				else
				{
					g.fillPolygon(x, y, 3);
				}
			}
			else if(polygoncase.get(i) == 5)
			{
				 g2.draw(new Line2D.Double(sp.x, sp.y, ep.x, ep.y));
			}
			else if(polygoncase.get(i) == 6)
			{
				g.setColor(Color.WHITE);
				g.fillRect(0, 0, 1920, 816);
			}
		}
	}
	public void getImage(Image img)
	{
		con = img;
	}
	public void undo()
	{
		int i = sv.size()-1;
		while(true)
		{
			if(colorcase.get(i) != Color.WHITE)
			{
				break;
			}
			i--;
		}
		lastColor.push(colorcase.get(i));
		intNum.push(i);
		colorcase.set(i,Color.WHITE);
		repaint();
	}
	public void redo()
	{
		int i = intNum.peek();
		Color j = lastColor.peek();
		intNum.pop();
		lastColor.pop();
		colorcase.set(i, j);
		repaint();
	}
	public void reset(int polyNum , Color col, int tic, int fil)
	{
		polygon = polyNum;
		color = col;
		thick = tic;
		fill = fil;
	}
	public void sizeUp()
	{
		int figureNum2 = figureNum-1;
		if(figureNum == 0)
		{
			figureNum2 = sv.size()-1;
		}
		Point up = sv.get(figureNum2);
		Point up2 = se.get(figureNum2);
		
		if(up.x < up2.x)
		{
			if(up.y<up2.y)
			{
				up = new Point(up.x-10,up.y-10);
				up2 = new Point(up2.x+10,up2.y+10);
			}
			else
			{
				up = new Point(up.x-10,up.y+10);
				up2 = new Point(up2.x+10,up2.y-10);
			}
		}
		else
		{
			if(up.y < up2.y)
			{
				up = new Point(up.x+10,up.y-10);
				up2 = new Point(up2.x-10,up2.y+10);
			}
			else
			{
				up = new Point(up.x+10,up.y+10);
				up2 = new Point(up2.x-10,up2.y-10);
			}
		}
		sv.set(figureNum2, up);
		se.set(figureNum2, up2);
		repaint();
		
	}
	public void sizeDown()
	{
		int figureNum2 = figureNum-1;
		if(figureNum == 0)
		{
			figureNum2 = sv.size()-1;
		}
		Point up = sv.get(figureNum2);
		Point up2 = se.get(figureNum2);
		
		if(up.x < up2.x)
		{
			if(up.y<up2.y)
			{
				up = new Point(up.x+10,up.y+10);
				up2 = new Point(up2.x-10,up2.y-10);
			}
			else
			{
				up = new Point(up.x+10,up.y-10);
				up2 = new Point(up2.x-10,up2.y+10);
			}
		}
		else
		{
			if(up.y < up2.y)
			{
				up = new Point(up.x-10,up.y+10);
				up2 = new Point(up2.x+10,up2.y-10);
			}
			else
			{
				up = new Point(up.x-+10,up.y-10);
				up2 = new Point(up2.x+10,up2.y+10);
			}
		}
		sv.set(figureNum2, up);
		se.set(figureNum2, up2);
		repaint();
	}
	public void choose()
	{
		while(colorcase.get(figureNum) == Color.WHITE)
		{
			if(figureNum > 0)
			{
				colorcase.set(figureNum-1, selectLast.peek());
				selectLast.pop();
			}
			if(colorcase.get(colorcase.size()-1)==Color.CYAN)
			{
				colorcase.set(colorcase.size()-1, selectLast.peek());
				selectLast.pop();
			}
			selectLast.push(colorcase.get(figureNum));
			figureNum++;
			if(figureNum == sv.size())
			{
				figureNum = 0;
			}
		}
		if(figureNum > 0)
		{
			colorcase.set(figureNum-1, selectLast.peek());
			selectLast.pop();
		}
		if(colorcase.get(colorcase.size()-1)==Color.CYAN)
		{
			colorcase.set(colorcase.size()-1, selectLast.peek());
			selectLast.pop();
		}
		
		selectLast.push(colorcase.get(figureNum));
		
		
		colorcase.set(figureNum, Color.CYAN);
		
		figureNum++;
		if(figureNum == sv.size())
		{
			figureNum = 0;
		}
		repaint();
	}
	public void up()
	{
		int figureNum2 = figureNum-1;
		if(figureNum == 0)
		{
			figureNum2 = sv.size()-1;
		}
		Point up = sv.get(figureNum2);
		Point up2 = se.get(figureNum2);
		
		up = new Point(up.x,up.y-10);
		up2 = new Point(up2.x,up2.y-10);
		
		sv.set(figureNum2, up);
		se.set(figureNum2, up2);
		repaint();
	}
	public void down()
	{
		int figureNum2 = figureNum-1;
		if(figureNum == 0)
		{
			figureNum2 = sv.size()-1;
		}
		Point up = sv.get(figureNum2);
		Point up2 = se.get(figureNum2);
		
		up = new Point(up.x,up.y+10);
		up2 = new Point(up2.x,up2.y+10);
		
		sv.set(figureNum2, up);
		se.set(figureNum2, up2);
		repaint();
	}
	public void right()
	{
		int figureNum2 = figureNum-1;
		if(figureNum == 0)
		{
			figureNum2 = sv.size()-1;
		}
		Point up = sv.get(figureNum2);
		Point up2 = se.get(figureNum2);
		
		up = new Point(up.x+10,up.y);
		up2 = new Point(up2.x+10,up2.y);
		
		sv.set(figureNum2, up);
		se.set(figureNum2, up2);
		repaint();
	}
	public void left()
	{
		int figureNum2 = figureNum-1;
		if(figureNum == 0)
		{
			figureNum2 = sv.size()-1;
		}
		Point up = sv.get(figureNum2);
		Point up2 = se.get(figureNum2);
		
		up = new Point(up.x-10,up.y);
		up2 = new Point(up2.x-10,up2.y);
		
		sv.set(figureNum2, up);
		se.set(figureNum2, up2);
		repaint();
	}
	public void changeColor(Color color)
	{
		int figureNum2 = figureNum-1;
		if(figureNum == 0)
		{
			figureNum2 = sv.size()-1;
		}
		colorcase.set(figureNum2, color);
		
		selectLast.pop();
		selectLast.push(colorcase.get(figureNum2));
		colorcase.set(figureNum2, Color.CYAN);
		
		repaint();
		
	}
	public void resetPanel()
	{
		polygoncase = new ArrayList<>();
		colorcase = new ArrayList<>();
		thickcase = new ArrayList<>();
        sv = new Vector<>();
        se = new Vector<>();
        con = null;
        //polygoncase.add(6);
        //colorcase.add(Color.WHITE);
        //thickcase.add(1);
        //sv.add(new Point(0,0));
        //se.add(new Point(0,0));
		repaint();
		polygon = 5;
		color = Color.BLACK;
		thick = 1;
	}
		
	class MyMouseListener extends MouseAdapter
	{
		public void mousePressed(MouseEvent e)
		{
			polygoncase.add(polygon);
	        colorcase.add(color);
	        thickcase.add(thick);
	        fillcase.add(fill);
			sv.add(e.getPoint()); // Ŭ���Ѻκ��� ����������
		}
		public void mouseReleased(MouseEvent e)
		{
			se.add(e.getPoint()); // �巡�� �Ѻκ��� ����������
			repaint(); // �ٽñ׷���
		}

	}
	class MyMouseMotionListener implements MouseMotionListener, ActionListener
	{

		@Override
		public void mouseDragged(MouseEvent e) 
		{
			if(polygon==5)
			{
				polygoncase.add(polygon);
				colorcase.add(color);
	        	thickcase.add(thick);
	        	fillcase.add(fill);
				sv.add(e.getPoint());
				se.add(e.getPoint());
				repaint();
			}
		}

		@Override
		public void mouseMoved(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		
	}
}
