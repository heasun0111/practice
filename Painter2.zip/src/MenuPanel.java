import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
//import java.io.FileInputStream;
import java.io.FileOutputStream;
//import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javax.swing.filechooser.FileNameExtensionFilter;



public class MenuPanel extends JMenuBar
{

   private static final long serialVersionUID = 1L;
   DrawPanel draw;
   BufferedImage img = null;
   public ImageIcon background = new ImageIcon();
   JMenu menuFile = new JMenu("����");
   JMenuItem item_open = new JMenuItem("����");
   JMenuItem item_save = new JMenuItem("����");
   JMenuItem item_Exit = new JMenuItem("����");
   JMenuItem item_new = new JMenuItem("��ü�����");
   JMenuItem item_new_window = new JMenuItem("��â �����");
   
   JMenu menuAbout = new JMenu("������");
   JMenuItem item_made = new JMenuItem("������");
   JMenuItem item_ver = new JMenuItem("����");
   
     
   String filePath_o;
   static String filePath;
   static Image imgI;
   
   public MenuPanel()
   {
     this.setLayout(null);
     this.setSize(1920,200);
     item_open.addActionListener(new EventHandler());
      item_save.addActionListener(new EventHandler());
      item_Exit.addActionListener(new EventHandler());
      item_new.addActionListener(new EventHandler());
      item_new_window.addActionListener(new EventHandler());
      menuFile.add(item_new_window);
      menuFile.addSeparator();
      menuFile.add(item_open);
      menuFile.add(item_save);
      menuFile.addSeparator();
      menuFile.add(item_new);
      menuFile.addSeparator();
      menuFile.add(item_Exit);
      
      item_made.addActionListener(new EventHandler());
      item_ver.addActionListener(new EventHandler());
      menuAbout.add(item_made);
      menuAbout.add(item_ver);
      
      this.add(menuFile);
      this.add(menuAbout);
      
      
   }
   public void getDrawPanel(DrawPanel sample)
   {
	   draw = sample;
   }
   
   class EventHandler implements ActionListener
   {
      JFileChooser choice;
      File file;
      public EventHandler()
      {
         choice = new JFileChooser();
      }
      public void actionPerformed(ActionEvent ae) throws ClassCastException
      {
         Object obj = ae.getSource();
         
         if (obj == item_open)
         {
            int returnVal = choice.showOpenDialog(null);
            FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG & GIF image", "jpg","gif","png");
            choice.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
            choice.setFileFilter(filter);
            
            if (returnVal != JFileChooser.APPROVE_OPTION)
            {
               JOptionPane.showMessageDialog(null, "���� ������ �ϼ���", "���", JOptionPane.WARNING_MESSAGE);
               return;
            }
            else
            {
            	File file = choice.getSelectedFile();
               
               try 
               {
            	  img = ImageIO.read(file);
                  draw.getImage(img);
                  draw.repaint();
               }
               catch(Exception e)
               {
                  e.printStackTrace();
               }
               
            }
         }
         else if(obj == item_save)
         {
            //ȭ���� ����ϰ� ��ȯ���� ���� / ��� ���� �ִ�.
        	Container c = getRootPane();
        	img = new BufferedImage(draw.getWidth(), draw.getHeight(), BufferedImage.TYPE_INT_RGB);
        	/**
            FileNameExtensionFilter filter = new FileNameExtensionFilter("jpeg file", "jpg", "jpeg");
            FileNameExtensionFilter filter2 = new FileNameExtensionFilter("png file", "png");
            FileNameExtensionFilter filter3 = new FileNameExtensionFilter("gif file", "gif");
            choice.addChoosableFileFilter(filter);
            choice.addChoosableFileFilter(filter2);
            choice.addChoosableFileFilter(filter3);
            choice.setFileFilter(filter);**/
            choice.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
            int returnVal =choice.showSaveDialog(null);
            // ���� ��ư�� ������ ������ (APPROVE_OPTION --> Ȯ��â�� �������)
            if(returnVal !=JFileChooser.APPROVE_OPTION){
               JOptionPane.showMessageDialog(null, "���� ������ �ϼ���","���",JOptionPane.WARNING_MESSAGE);
               return;
            }else{
               //getSelectedFile �� ������ ���´� . getPath �������� ��ġ�� ���´�
               filePath_o =   choice.getSelectedFile().getPath();
               //pack();

               try {
            	  c.paint(img.getGraphics());
            	  Graphics2D g2 = img.createGraphics();
                  draw.paint(g2);
                  ImageIO.write(img, "png", new File(filePath_o.toString()));
                  FileOutputStream fos = new FileOutputStream(filePath_o,true);
                  ObjectOutputStream oos = new ObjectOutputStream(fos);
                  oos.close();
                  fos.close();
               } catch (Exception e) {
                  // TODO �ڵ� ������ catch ����
                  e.printStackTrace();
               }
            }
       
         }
         else if(obj ==item_Exit)
         {
            System.exit(0);
         }
         else if(obj == item_new)
         {
        	 draw.resetPanel();
        	 draw.repaint();
         }
         else if (obj == item_made)
         {
        	 JOptionPane.showMessageDialog(null,"Made by\n \'����\',  \'���Ѽ�\',  \'������\'");
         }
         else if(obj == item_ver)
         {
        	 JOptionPane.showMessageDialog(null,"Painter Ver. 2.0");
         }
         else if(obj == item_new_window)
         {
        	 new GUI();
         }
      
      }
   }
   
}