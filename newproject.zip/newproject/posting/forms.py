from django import forms
from .models import Posting

class PostingUpdate(forms.ModelForm):
    class Meta:
        model = Posting
        fields = ['title','body']
#Meta데이터 : 상위 클래스에 대한 정보를 담고 있음