from django.shortcuts import render, get_object_or_404, redirect
from .models import Posting
from .forms import PostingUpdate

# Create your views here.
def update(request, posting_id):
    posting = Posting.objects.get(id=posting_id)
    if request.method =='POST':
        form = PostingUpdate(request.POST)
        if form.is_valid():
            posting.title = form.cleaned_data['title']
            posting.body = form.cleaned_data['body']
            posting.pub_date=timezone.now()
            posting.save()
            return redirect('/posting/' + str(posting.id))
    else:
        form = PostingUpdate(instance = posting)
 
        return render(request,'update.html', {'form':form})

def delete(request, posting_id):
    Posting.objects.get(id=posting_id).delete()
    return redirect('/')

from django.utils import timezone
def create(request):
    posting=Posting()
    posting.title=request.GET['title']
    posting.body=request.GET['body']
    posting.pub_date=timezone.datetime.now()
    posting.save()
    return redirect('/posting/'+str(posting.id))
    #redirect 위에꺼를 다 처리한 후 (url(외부페이지도 입력 가능))로 넘김
    #render는 내부 페이지 url

def posting(request):
    postings=Posting.objects
    return render(request, 'posting.html', {'postings':postings})

def detail(request, posting_id):
    posting_detail = get_object_or_404(Posting, pk=posting_id)
    return render(request, 'detail.html', {'posting':posting_detail})

def new(request):
    return render(request, 'new.html')
