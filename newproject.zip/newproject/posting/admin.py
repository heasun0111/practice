from django.contrib import admin
from .models import Posting

admin.site.register(Posting)
# Register your models here.
